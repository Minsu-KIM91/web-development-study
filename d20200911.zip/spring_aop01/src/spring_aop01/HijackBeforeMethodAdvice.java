package spring_aop01;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

public class HijackBeforeMethodAdvice implements MethodBeforeAdvice {

	
	
	
	@Override
	public void before(Method method, Object[] args, Object target) throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("공통관심사 업무 지정");
		System.out.println("핵심기능이 실행되기 전에 가로채기");
		
	}

}
