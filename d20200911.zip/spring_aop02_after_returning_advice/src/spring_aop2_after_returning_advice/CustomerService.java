package spring_aop2_after_returning_advice;

public interface CustomerService {
	public void printName();
	public void printEmail();
}
