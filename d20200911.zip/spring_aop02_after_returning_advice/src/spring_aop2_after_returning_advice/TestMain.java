package spring_aop2_after_returning_advice;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {
	//IOC와 setter DI를 이용해서 이름과 이메일을 출력해보세요.
	//출력: 당신의 이메일은 ~~~(변수)
	//		당신의 이름은 ~~~(변수)
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		
		CustomerService cs = context.getBean("proxyBean", CustomerService.class);
		
		cs.printName();
		cs.printEmail();
	}
}
