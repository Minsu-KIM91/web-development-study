package advice;

import java.io.File;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import org.springframework.aop.AfterReturningAdvice;

public class BizMethodAfterAdvice implements AfterReturningAdvice {

	@Override
	public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("핵심로직 실행 후 공통관심사 실행되었음 2");
		
		//매개 변수 출력해보기
//		System.out.println("returnValue: "+returnValue);
//		System.out.println("method : "+method.getName());
//		System.out.println("args[0]: "+args[0]);
//		System.out.println("target : "+target.getClass());
		
		//서버에 파일로 저장하기
		//C:\Users\alstn\Downloads\log\오늘날짜.txt
		
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMdd");
		
		String fileName = sdf.format(d);
		
		//파일 객체
		File f = new File("C:\\Users\\alstn\\Downloads\\log\\"+fileName+".txt");
		
		//파일 생성
		if(!f.exists()) {
			f.createNewFile();
		}
		
		
		//오늘날짜.txt
		//파일 이름 저장되었습니다.
		//(이체금액) 이체되었습니다.
		PrintWriter pw = new PrintWriter(f);
		
		pw.println(fileName+" 저장되었습니다.");
		pw.println(args[0]+" 이체되었습니다.");
		pw.flush();
		pw.close();
		//로그기록으로 이런식으로 남겨두면 나중에 감사자료로 사용할 수 있다.
		
	}

}
