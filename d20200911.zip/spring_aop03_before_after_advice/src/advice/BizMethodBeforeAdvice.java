package advice;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

public class BizMethodBeforeAdvice implements MethodBeforeAdvice  {

	
	
	@Override
	public void before(Method method, Object[] args, Object target) throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("핵심로직전에 공통 관심사 실행되었음");
	}

}
