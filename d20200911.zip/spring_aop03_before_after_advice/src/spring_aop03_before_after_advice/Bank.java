package spring_aop03_before_after_advice;

public interface Bank {
	public void transfer(int money);
}
