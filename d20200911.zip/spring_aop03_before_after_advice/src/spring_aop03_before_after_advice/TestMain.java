package spring_aop03_before_after_advice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {
	public static void main(String[] args) {
		ApplicationContext ctx = new GenericXmlApplicationContext("app.xml");
		
		Bank b = ctx.getBean("proxyBean", Bank.class);
		
		b.transfer(5000);
	}
}
