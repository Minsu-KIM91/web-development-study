package advice;

import org.springframework.aop.ThrowsAdvice;

public class hijackAdvice implements ThrowsAdvice{
	//직접 작성해야함. 무조건!! ctrl+space 제공 x
	public void  afterThrowing(IllegalArgumentException e) {
		System.out.println("Hijack Throw Exception");
	}
}
