package spring_aop04_after_throw_advice;

public interface Message {
	public void printMsg();
	public void printThrowException();
}
