package spring_aop04_after_throw_advice;

public class MessageImple implements Message {
	
	String msg;
	
	
	
	
	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public void printMsg() {
		// TODO Auto-generated method stub
		System.out.println("출력 메시지: "+msg);
	}

	@Override
	public void printThrowException() {
		// TODO Auto-generated method stub
		throw new IllegalArgumentException();
		//강제로 익셉션 터뜨림.
	}
	
}
