package spring_aop04_after_throw_advice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {
	public static void main(String[] args) {
		ApplicationContext ctx = new GenericXmlApplicationContext("app.xml");
		
		Message msg = ctx.getBean("proxyBean", Message.class);
		
		msg.printMsg();
		
		try {
			msg.printThrowException();
			
		}catch(IllegalArgumentException ie) {
			//보통 익셉션이 발생하면 캐치에서 처리
			//현재는 하이잭이 할 것이므로 여기에서 아무것도 안함
			
//			ie.getStackTrace();
		}
	}
}
