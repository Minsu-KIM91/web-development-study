package advice;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.util.StopWatch;

public class CheckTime implements MethodInterceptor {
	
	
	
	
	
	
	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		//around 한 시간 구하기
		
		/*
		long before = System.currentTimeMillis();
		
		long after = System.currentTimeMillis();
		
		before에서 after를 빼면 메소드 수행 시간을 구할 수 있음.		
		이런 작업이 많이 쓰이므로 객체로 만들어 놨음.
		*/
		StopWatch sw = new StopWatch();
		//현재 시각
		sw.start();
		//메소드 실행 
		Object obj = invocation.proceed();
		
		//멈춘 시간.
		sw.stop();
		
		System.out.println("처리시간: "+sw.getTotalTimeSeconds());		
		
		
		return obj;
	}
	
}
