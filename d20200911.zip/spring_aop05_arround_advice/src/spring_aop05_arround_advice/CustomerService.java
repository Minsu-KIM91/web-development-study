package spring_aop05_arround_advice;

public interface CustomerService {
	public void printName();
	public void printEmail();
}
