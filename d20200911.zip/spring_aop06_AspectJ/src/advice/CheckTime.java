package advice;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.util.StopWatch;

public class CheckTime {
		
		public Object logAround(ProceedingJoinPoint pjp) throws Throwable {
			
			System.out.println(pjp.getSignature().getName());
			
			StopWatch sw = new StopWatch();
			//현재 시각
			sw.start();
			//메소드 실행 
			Object obj = pjp.proceed();
			
			//멈춘 시간.
			sw.stop();
			
			System.out.println("처리시간: "+sw.getTotalTimeSeconds());
			return obj;
		}
	
	
	
				
		
		
	
}
