package spring_aop06_AspectJ;

public interface CustomerService {
	public void printName();
	public void printEmail();
}
