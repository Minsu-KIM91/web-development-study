package advice;

import java.io.File;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.aop.AfterReturningAdvice;

public class CheckTimeWeapon1 implements AfterReturningAdvice{

	@Override
	public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
		
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMdd - hh:mm:ss");
		
		String usedTime = sdf.format(d);
		
		File f = new File("C:\\Users\\alstn\\Downloads\\log\\weapon1.txt");
		
		if(!f.exists()) {
			f.createNewFile();
		}
		
		PrintWriter pw = new PrintWriter(f);
		pw.println(usedTime + " : 무기 사용 시각");
		pw.flush();
		pw.close();
		
	}


	
}
