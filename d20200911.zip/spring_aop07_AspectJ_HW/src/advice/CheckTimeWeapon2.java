package advice;

import java.io.File;
import java.io.PrintWriter;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aspectj.lang.JoinPoint;


// aspectj
public class CheckTimeWeapon2 {
	public Object afterReturn(JoinPoint jp) throws Throwable {
		
		Date d = new Date();
		
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMdd - hh:mm:ss");
		
		Object obj = jp.getTarget();
		
		System.out.println("obj : " +obj.getClass().getName());
		
		String usedTime = sdf.format(d);
		
		File f = new File("C:\\Users\\alstn\\Downloads\\log\\weapon2.txt");
		
		if(!f.exists()) {
			f.createNewFile();
		}
		
		PrintWriter pw = new PrintWriter(f);
		pw.println(usedTime + " : 무기 사용 시각");
		pw.flush();
		pw.close();
		
		return obj;
		
	}
}
