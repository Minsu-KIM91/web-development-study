package spring_aop07_AspectJ_HW;

public interface Weapon {
	public void fire();
	public void reload();
}
