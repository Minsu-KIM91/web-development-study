package spring_aop08_AspectJ_anno;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.util.StopWatch;

@Aspect   //이걸 선언하면 관점객체가 됨.
public class CheckTime {
	
	@Pointcut("execution (public * printName(..)) ")    //규약 설정(표현설정)
	public void publicTarget() {}
	
	
	@Around("publicTarget()")
	public Object logAround(ProceedingJoinPoint pjp) throws Throwable{
		String methodName = pjp.getSignature().getName();
		
		StopWatch sw = new StopWatch();
		sw.start();
		
		Object obj = pjp.proceed();
		
		sw.stop();
		
		System.out.println("수행시간: "+sw.getTotalTimeSeconds());
		
		return obj;
	}
	
	
}
