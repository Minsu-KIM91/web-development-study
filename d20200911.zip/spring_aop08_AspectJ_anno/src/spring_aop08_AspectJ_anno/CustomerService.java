package spring_aop08_AspectJ_anno;

public interface CustomerService {
	public void printName();
	public void printEmail();
}
