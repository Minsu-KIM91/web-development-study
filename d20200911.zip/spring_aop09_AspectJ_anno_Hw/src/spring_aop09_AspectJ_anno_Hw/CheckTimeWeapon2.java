package spring_aop09_AspectJ_anno_Hw;

import java.io.File;
import java.io.PrintWriter;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;


@Aspect
public class CheckTimeWeapon2 {
	
	@Pointcut("execution (public * fire())")
	public void publicTarget() {}
	
	
	@AfterReturning("publicTarget()")
	public Object afterReturn(JoinPoint jp) throws Throwable {
		
		Date d = new Date();
		
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMdd - hh:mm:ss");
		
		Object obj = jp.getTarget();
		
		System.out.println("obj : " +obj.getClass().getName());
		
		String usedTime = sdf.format(d);
		
		File f = new File("C:\\Users\\alstn\\Downloads\\log\\annoweapon.txt");
		
		if(!f.exists()) {
			f.createNewFile();
		}
		
		PrintWriter pw = new PrintWriter(f);
		pw.println(usedTime + " : 무기 사용 시각");
		pw.flush();
		pw.close();
		
		return obj;
		
	}
}
