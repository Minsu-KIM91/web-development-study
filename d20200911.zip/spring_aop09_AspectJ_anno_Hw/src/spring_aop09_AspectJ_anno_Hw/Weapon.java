package spring_aop09_AspectJ_anno_Hw;

public interface Weapon {
	public void fire();
	public void reload();
}
