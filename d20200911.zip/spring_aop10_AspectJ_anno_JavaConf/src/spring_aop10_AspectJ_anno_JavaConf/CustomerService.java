package spring_aop10_AspectJ_anno_JavaConf;

public interface CustomerService {
	public void printName();
	public void printEmail();
}
