package spring_aop10_AspectJ_anno_JavaConf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

//spring bean configuration file 대신 자바 객체가 역할을 함.
@Configuration
@EnableAspectJAutoProxy
public class JavaConf {
	
	@Bean(name="cs")
	public CustomerServiceImple cs() {
	CustomerServiceImple csi = new CustomerServiceImple();
	csi.setEmail("asdf@nasdr.com");
	csi.setName("유관순");
	
	return csi;
	}
	
	@Bean
	public CheckTime xt() {
		CheckTime cct = new CheckTime(); 
				
		cct.publicTarget();
		return cct;
	}
	
	
	
}
