package spring_app01;

public interface Hello {
	public void sayHello(String name);
	
}
