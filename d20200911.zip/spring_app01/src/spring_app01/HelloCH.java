package spring_app01;

public class HelloCH implements Hello {

	@Override
	public void sayHello(String name) {
		System.out.println(name+" 니 취 팔러마?");
		
	}

}
