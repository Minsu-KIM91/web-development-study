package spring_app02;

public interface Beverage {
	public void drink(String name);
	
}
