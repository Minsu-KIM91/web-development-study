package spring_app02;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class TestMain {
	public static void main(String[] args) {
		//출력 : 홍길동님이 커피를 홀짝홀짝 마셔요.
		//자바클래스 호출하는 형태로 구현
//		Beverage b = new CoffeeImple("초코우유");
//		b.drink("홍길동");
		
		
		/* IOC 와 DI 중요 포인트다. 스프링의 1차 핵심. */
		
		//설정만 할 수 있다면 편한게 스프링프레임워크다....지금은 설정까지 다해서 빡셈.
		//아래와 위에는 다름.(10~12라인)
		
		//스프링 설정으로 구현
		//홍길동님이 다른 음료를 마실 수 있도록 처리.
		//대부분에 프로그램에는 main에 실행부만 넣어놓는다. 그러니까 최대한 변화가 적은 형태로 감.
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/app.xml"));
		
		
		//DI(Dependency Injection) : 의존 관계에 있어서 xml에 있는 정보를 스프링이 run time시
		//불러와서 동작.... 여러종류의 음료를 다른 객체로 불러와 저장.
		Object obj = factory.getBean("b2");
		Object obj2 = factory.getBean("b2");
		
		//메모리를 줄이기 위해서 주소가같음 위에 getBean값에 b2로 2개 다 넣어서 아래에 출력하면ㅁ @뒤 값이 같음.
		//내부적으로 스프링은 bean 관리를  singleTone으로 관리하는 것이기 때문.
		System.out.println(obj);
		System.out.println(obj2);
		
		MachineCoffee mc1= new MachineCoffee();
		MachineCoffee mc2= new MachineCoffee(); 
		
		System.out.println(mc1);
		System.out.println(mc2); //같이 선언해도 @뒤에 주소가ㅓ 달라서 다른 객체.
		
		
		Beverage b = (Beverage)obj;
		b.drink("홍길동");
		
		
		
		
	}
}



























