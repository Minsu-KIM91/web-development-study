package spring_app03;

public class DotPrinter implements Printer {
	
	String msg;
	
	public DotPrinter() {
		
	}
	
	
	public DotPrinter(String msg) {
		this.msg=msg; 
	}


	@Override
	public void printing(String msg) {
		System.out.println("DotPrinter 출력: 또또또...");
		System.out.println(msg);
		
	}
	
}
