package spring_app03;

public class LaserPrinter implements Printer {

	
	
	@Override
	public void printing(String msg) {
		System.out.println("Laser 프린터  : 찌이이이이이~");
		System.out.println(msg);
		
	}

}
