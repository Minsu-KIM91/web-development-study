package spring_app03;

public interface Printer {
	public void printing(String msg);
}

/*
 * +spring_app03 project
 * 
 * - spring_app03 package:
 * 
 * printer interface - printing(String mag)
 * 
 * 
 * - 빈 등록 : printer.xml
 * 
 * -TestMain.java 스프링으로 출력: DotPrinter 출력 : 또또또 ... 오늘은 목요일
 * 
 * 
 * ----------------위는 실습해보기----------
 */