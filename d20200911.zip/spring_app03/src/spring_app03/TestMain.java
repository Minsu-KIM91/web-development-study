package spring_app03;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class TestMain {
	public static void main(String[] args) {
		//설정파일 읽어오기
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/printer.xml"));
		
		//1.
		Object obj = factory.getBean("dot");
		
		/* System.out.println(obj); */		
		Printer p = (Printer)obj;
		p.printing("오늘은 목요일");
		
		//2.
		Object obj2 = factory.getBean("laser");
		Printer p2 = (Printer)obj2;
		p2.printing("내일은 금요일");
		
		
		//3.
		Printer print = factory.getBean("dot", Printer.class);		
		print.printing("주말은 언제와");
		
		
		
		
	}
}
