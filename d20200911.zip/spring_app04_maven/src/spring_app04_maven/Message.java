package spring_app04_maven;

public interface Message {
	public void sayHello(String str);
}
