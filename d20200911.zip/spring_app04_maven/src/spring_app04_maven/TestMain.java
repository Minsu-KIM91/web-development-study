package spring_app04_maven;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class TestMain {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/app.xml"));
		//위에 밑줄 글씨는 버전업 되면서 기본적으로 제공되는 형태로 바뀌어서 저렇게 표시된다.
		
		Message message = factory.getBean("g", Message.class);
		
		message.sayHello("안녕");
	}
}
