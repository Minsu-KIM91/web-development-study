package spring_app05_maven;

import java.sql.Connection;

public class MysqlDAO implements CommonDAO {

	public MysqlDAO() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public Connection connect() {
		// TODO Auto-generated method stub
		return MysqlConnection.getInstance().getcoConnection();
	}

	@Override
	public void selectAll() {
		System.out.println("전부 다 출력 됨");
		
	}

}
