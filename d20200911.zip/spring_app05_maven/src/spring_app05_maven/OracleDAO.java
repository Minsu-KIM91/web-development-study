package spring_app05_maven;

import java.sql.Connection;

public class OracleDAO implements CommonDAO {

	public OracleDAO() {}
	
	@Override
	public Connection connect() {
		// TODO Auto-generated method stub
		return OracleXEConnection.getInstance().getcoConnection();
	}

	@Override
	public void selectAll() {
		System.out.println("데이터 잘 가져옴");
		
	}
	
}
