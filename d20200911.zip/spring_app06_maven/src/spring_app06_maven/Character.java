package spring_app06_maven;

public interface Character {
	public void walk();
	public void eat(String it);
	public void attack(Object obj);
	public void get(Object obj);
	
	
	
	
}
