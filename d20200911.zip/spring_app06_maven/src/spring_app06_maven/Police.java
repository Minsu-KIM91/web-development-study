package spring_app06_maven;

public class Police implements Character {
	
	Weapon w;
	Gun g;
	StunGun s;
	
	int hp;
	
	public Police() {
		this.hp=100;
	}
	
	//생성자
//	public Police(Weapon w, int hp) {
//		this.w = w;
//		this.hp = hp;
//	}
	
	
	
	
	@Override
	public void walk() {
		System.out.println("뚜벅뚜벅 순찰중..");
		
	}
	
	//생성자 없이도 데이터를 주고 받을 수 있는 방법: getter/setter
	public Weapon getW() {
		return w;
	}

	public void setW(Weapon w) {
		this.w = w;
	}

	public Gun getG() {
		return g;
	}

	public void setG(Gun g) {
		this.g = g;
	}

	public StunGun getS() {
		return s;
	}

	public void setS(StunGun s) {
		this.s = s;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	@Override
	public void eat(String it) {
		System.out.println(it+" 맛있게 먹는 중..");
		
	}

	@Override
	public void attack(Object obj) {
		System.out.println(obj+ " 공격");
		w.use(); //무기 사용해라. 근데 어떤 무기를 사용할 지 결정이 안되어있다.
	}

	@Override
	public void get(Object obj) {
		System.out.println(obj+"를 습득했습니다.");
		
	}
	
}
