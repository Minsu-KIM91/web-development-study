package spring_app06_maven;

public class StunGun implements Weapon {

	int bullet;
	
	public StunGun() {
		this.bullet = 1;
	}
	
	
	
	@Override
	public void use() {
		if(bullet >0) {
			System.out.println("지지직!");
			bullet --;
		}
		
	}

	@Override
	public void reuse() {
		System.out.println("새로운 배터리 교체중..");
		bullet = 1;
		
		
	}

	@Override
	public void drop() {
		System.out.println("배터리 방전. 아놔");
		bullet = 0;
		
	}

}
