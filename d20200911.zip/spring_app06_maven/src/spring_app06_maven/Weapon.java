package spring_app06_maven;

public interface Weapon {
	public void use();
	public void reuse();
	public void drop();
}
