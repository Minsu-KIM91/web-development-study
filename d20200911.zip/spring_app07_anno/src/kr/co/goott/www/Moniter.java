package kr.co.goott.www;

public interface Moniter {
	public void showMonitor();
}
