package kr.co.goott.www;

public interface Monitor {
	public void showMonitor();
}
