package kr.co.goott.www;

public class Sender {
	public void show() {
		System.out.println("sender class의 show() method");
	}
}
