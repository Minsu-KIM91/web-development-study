package kr.co.goott.www;

import org.springframework.beans.factory.annotation.Autowired;

public class SystemMoniter implements Moniter {
	
//	<!-- 자동으로 bean을 인식시켜주는 --> 어노테이션
//	<bean class="org.springframework.beans.factory.annotation.AutowiredAnnotationBeanPostProcessor"></bean>
	@Autowired	 //위 때문에 붙여줌.
	Sender sender;
	
	public void setSender(Sender sender) {
		this.sender = sender;
	}
	
	@Override
	public void showMonitor() {
		if(sender!=null) sender.show();
		else System.out.println("sender is null");
		
	}
	
}
