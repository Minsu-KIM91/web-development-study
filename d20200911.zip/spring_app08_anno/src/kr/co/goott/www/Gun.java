package kr.co.goott.www;

public class Gun implements Weapon {

	int bullet;
	
	public Gun() {
		this.bullet = 6;
	}
	
	
	@Override
	public void use() {
		if(bullet >0) {
			System.out.println("빵!");
			bullet --;
		}
		
	}

	@Override
	public void reuse() {
		System.out.println("재장전 중");
		bullet = 6;
		
	}

	@Override
	public void drop() {
		System.out.println("총알이 다 떨어졌다. 아놔");
		bullet = 0;
		
	}
	
}
