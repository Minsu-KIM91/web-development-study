package kr.co.goott.www;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Police implements Character {
	
	@Autowired		//자동으로 인식해줘라 는 것이기 때문에 2개 이상 객체가 같이 있으면(건, 스턴건) 자동으로 인식하지 못하고 에러를 발생시킴. 
	@Qualifier("g1")
	Weapon w;
	//하나를 지정해주든지 아님 하나만 운영하든지 둘 중 하나를 해야함. @Qualifier("g1") 
	
	//이거 아래 없애도 된다는데...@Autowired때문에...
	//기존에 건, 스턴건 만들어서 있었음 (app06프로젝트 복사해옴)
	
	
	
	int hp;
	
	public Police() {
		this.hp=100;
	}
	
	//생성자
//	public Police(Weapon w, int hp) {
//		this.w = w;
//		this.hp = hp;
//	}
	
	
	
	
	@Override
	public void walk() {
		System.out.println("뚜벅뚜벅 순찰중..");
		
	}
	
	//생성자 없이도 데이터를 주고 받을 수 있는 방법: getter/setter
	public Weapon getW() {
		return w;
	}

	public void setW(Weapon w) {
		this.w = w;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	@Override
	public void eat(String it) {
		System.out.println(it+" 맛있게 먹는 중..");
		
	}

	@Override
	public void attack(Object obj) {
		System.out.println(obj+ " 공격");
		w.use(); //무기 사용해라. 근데 어떤 무기를 사용할 지 결정이 안되어있다.
	}

	@Override
	public void get(Object obj) {
		System.out.println(obj+"를 습득했습니다.");
		
	}
	
}
