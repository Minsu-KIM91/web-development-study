package kr.co.goott.www;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;


//실행은 항상 이 파일에서 한다.
public class TestMain {
	public static void main(String[] args) {
		
				
		/*
		 * BeanFactory factory = new XmlBeanFactory(new
		 * FileSystemResource("src/app.xml"));
		 */
		
		ApplicationContext context = new ClassPathXmlApplicationContext("app.xml");
		
		Character ch1 = context.getBean("p1", Character.class);
		
		ch1.attack("도둑님");
		
		
	}
}
