package kr.co.goott.www;

public interface Weapon {
	public void use();
	public void reuse();
	public void drop();
}
