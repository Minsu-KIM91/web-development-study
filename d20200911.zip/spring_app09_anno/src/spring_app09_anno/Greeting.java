package spring_app09_anno;

public interface Greeting {
	public void printMsg();
}
