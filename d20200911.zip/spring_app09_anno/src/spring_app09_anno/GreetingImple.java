package spring_app09_anno;

import org.springframework.beans.factory.annotation.Autowired;

public class GreetingImple implements Greeting {
	
	String msg;
	
	@Autowired //auto ctrl+space => 필요한 객체를 찾아서 자동으로 묶어줘 cf) BeanFactory계열로는 사용x
	NowTime nt;
	
//	public GreetingImple(String msg) {
//		this.msg=msg;
//	}
	
	
	
	public void setMsg(String msg) {
		this.msg = msg;
	}



	public void setNt(NowTime nt) {
		this.nt = nt;
	}



	@Override
	public void printMsg() {
		System.out.println("현재 시각: "+ nt.getTime()+" - "+msg);		
	}
	
}
