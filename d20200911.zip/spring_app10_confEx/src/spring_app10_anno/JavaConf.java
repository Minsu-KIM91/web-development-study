package spring_app10_anno;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration	//자바설정 파일
public class JavaConf {
	
	//자바설정 파일 내부에 bean등록한다면 무조건 1개는 name등록해야한다.(권장사항)
	@Bean 
	public PhoneOS phoneos() {
		PhoneOS po = new PhoneOS();
		po.setName("아이폰");
		po.setVersion("IOS 13");
		return po;
		
	}
	
	@Bean(name = "p")
	public SmartPhone smartPhone() {
		SmartPhone sp = new SmartPhone();
		sp.setOs(phoneos());
		return sp;
	}
}
