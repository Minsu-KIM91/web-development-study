package spring_app10_anno;

public interface Phone {

	
	public void call(String callNumber);
	public void sendMsg(String msg);
	
}
