package spring_app10_anno;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

public class TestMain {
	public static void main(String[] args) {
		//Phone phone = new smartPhone();
		
//		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/app.xml"));
		
//		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("app.xml"));
//		Phone phone = factory.getBean("sp", Phone.class);
		/* annotation사용하면 factory사용불가 */
		
		//ApplicationContext context = new ClassPathXmlApplicationContext("app.xml");
		
										//new 뒤에가 구현 클래스
		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConf.class);
		
		
		//Phone phone = context.getBean("sp", Phone.class);
		Phone phone = context.getBean("p", Phone.class);
		
		phone.call("010-9599-8215");
		phone.sendMsg("으아ㅏ아아아아아아아");
		
		
	}
}
