package spring_app11_javaconf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//xml 설정도 가능하고 자바 객체를 통해서도 spring bean에 대한 설정 정보를 갖게 할 수 있다.


@Configuration
public class JavaConf {

	
	@Bean
	public Sender sender() {
//		Sender s = new Sender();
//		return s;
		return new Sender();
		
	}
	
	//최종적으로 아래의 객체가 호출되야하기 때문에 이름이 있어야 한다.(name= "")
	@Bean(name = "m")
	public SystemMoniter systemMoniter() {
		SystemMoniter sm = new SystemMoniter();
		sm.setSender(sender());
		return sm;
	}
	
}
