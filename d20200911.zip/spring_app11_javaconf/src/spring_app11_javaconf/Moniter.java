 package spring_app11_javaconf;

public interface Moniter {
	public void showMonitor();
}
