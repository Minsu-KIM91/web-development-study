package spring_app11_javaconf;

public class Sender {
	public void show() {
		System.out.println("sender class의 show() method");
	}
}
