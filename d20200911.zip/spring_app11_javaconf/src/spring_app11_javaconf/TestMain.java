package spring_app11_javaconf;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {
	public static void main(String[] args) {
		
		//자바 객체 설정 읽어들이기
		// new 뒤에는 주소를 어떻게 찾아올 것이냐.에 해당하는 것임
//		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConf.class);
		BeanFactory factory = new AnnotationConfigApplicationContext(JavaConf.class);
		
		//위 두 방법의 차이는 무엇인가
		
		
		
		/* Moniter mt = context.getBean("sm", Monitor.class); */
		Moniter mt = factory.getBean("m", Moniter.class);
		
		//오버라이드된 걸 부른다.(systemMoniter.java)안에
		mt.showMonitor();
	}
}
