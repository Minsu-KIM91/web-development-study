package spring_app12_DaoBean;

public interface DAO {
	
	//전체 데이터 갯수 구하기	
	public int selectCount();
	
	
	
}
