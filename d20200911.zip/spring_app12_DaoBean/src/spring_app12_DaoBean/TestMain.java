package spring_app12_DaoBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		
		DAO d = context.getBean("dao", DAO.class);
		
		System.out.println("부서테이블의 총 row 수:"+d.selectCount());
		
		//아래 코드 없어도 된다. "종료 메소드 호출"이라는 콘솔로그를 보고 싶어서 그럼.
		((AbstractApplicationContext) context).close();
	}
}
