package spring_app13_jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class MysqlDAO implements Dao {
	
	private JdbcTemplate jdbcTemplate;
	StringBuffer sb = new StringBuffer();
//	PreparedStatement pstmt = null;
//	ResultSet rs =null;
		
	//setter 처리.
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	
	
	@Override
	public List<DeptDTO> selectAll() {
		sb.setLength(0);
		sb.append("select * from dept ");
		
		//로우별로 매핑하는 애.
		//RowMapper : db의 테이블에 들어있는 각 row를 틀에 맞게 담아서(매핑) 구현할 객체
		//인터페이스이므로 new로 구현이 되질 않는다.-> 구현할 객체가 필요한데, 한번 쓰고 말 것이므로 익명 클래스로 구현.

								//아래는 익명 Inner Class
		RowMapper<DeptDTO> rm = new RowMapper<DeptDTO>() {
			@Override
			public DeptDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				
//				DeptDTO dto = new DeptDTO();
//				int deptno = rs.getInt(1);
//				String dname = rs.getString(2);
//				String loc = rs.getString(3);
//				
//				dto.setDeptno(deptno);
//				dto.setDname(dname);
//				dto.setLoc(loc);				
//				
//				return dto;
					
				//위 코드를 줄이면!!		
				return new DeptDTO(rs.getInt(1), rs.getString(2), rs.getString(3));
			}//mapRow() end	
			
			
			
		};//RowMapper end
		
			List<DeptDTO> list = jdbcTemplate.query(sb.toString(), rm);
		
		return list;
		
	}//selectAll() end

	
	@Override
	public DeptDTO selectOne(int no) {
		sb.setLength(0);
		sb.append("select * from dept ");
		sb.append("where deptno = ? ");
		
		RowMapper<DeptDTO> rm = new RowMapper<DeptDTO>() {
			@Override
			public DeptDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return new DeptDTO(rs.getInt(1), rs.getString(2), rs.getString(3));
			}
			
		};
		
		//쿼리문에 들어갈 ? 값을 넣기 위해 작성함. -> 사용자가 입력한 번호 = no
		DeptDTO dto = jdbcTemplate.queryForObject(sb.toString(), rm, no);
		return dto;
	}

	@Override
	public void insertOne(DeptDTO dto) {
		sb.setLength(0);
		sb.append("insert into dept ");
		sb.append("values (?, ?, ?) ");
		
		//입력만 하면 됨. 받아오는 작업x
//		jdbcTemplate.update(sql문, ?에 들어갈 값을 (,)를 기준으로 순서대로 입력)
		int result = jdbcTemplate.update(sb.toString(), dto.getDeptno(), dto.getDname(), dto.getLoc());
		
		System.out.println("insert 결과:"+result);
		
		
	}

	@Override
	public void updateOne(DeptDTO dto) {
		sb.setLength(0);
		sb.append("update dept ");
		sb.append("set dname = ?, loc = ? ");
		sb.append("where deptno = ? ");
		
		int result = jdbcTemplate.update(sb.toString(), dto.getDname(), dto.getLoc(), dto.getDeptno());
		System.out.println("update 결과:"+result);
	}

	@Override
	public void deleteOne(int no) {
		sb.setLength(0);
		sb.append("delete from dept ");
		sb.append("where deptno = ? ");
		
		int result = jdbcTemplate.update(sb.toString(), no);
		System.out.println("delete 결과:"+result);
		
		
		
	}

}




























