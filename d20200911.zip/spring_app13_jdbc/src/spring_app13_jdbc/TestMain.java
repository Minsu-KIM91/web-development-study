package spring_app13_jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		
		Dao d = context.getBean("dao", Dao.class);
		
		//전체 데이터를 list 인터페이스 객체로 리턴
//		List<DeptDTO> list = d.selectAll();
//		
//		for(DeptDTO dto : list) {
//			System.out.println(dto.getDeptno()+"\t"+dto.getDname()+"\t"+dto.getLoc());
		
//		}
		
		System.out.println("-------------------------");
//		DeptDTO dto1 = d.selectOne(30);
//		System.out.println(dto1.getDeptno()+"\t"+dto1.getDname()+"\t"+dto1.getLoc());
		
		System.out.println("-------------------------");
//		DeptDTO dto2 = new DeptDTO(60, "영업", "체코");
//		d.insertOne(dto2);
		
		
		System.out.println("-------------------------");
//		DeptDTO dto3 = new DeptDTO(60, "QA", "뉴욕");
//		d.updateOne(dto3);
		
		System.out.println("-------------------------");
		d.deleteOne(60);
	}
}
