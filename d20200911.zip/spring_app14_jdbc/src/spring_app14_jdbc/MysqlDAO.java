package spring_app14_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;


public class MysqlDAO implements Dao{
	
	private JdbcTemplate JdbcTemplate;
	StringBuffer sb = new StringBuffer();
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		JdbcTemplate = jdbcTemplate;
	}
	
	
	
	
	
	
	@Override
	public List<EmpDTO> selectAll() {
		sb.setLength(0);
		sb.append("select * from emp ");
		
		RowMapper<EmpDTO> rm = new RowMapper<EmpDTO>() {
			@Override
			public EmpDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				
			return new EmpDTO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getInt(6), rs.getInt(7), rs.getInt(8));
		}//mapRow() end				
			
			
		};//RowMapper end
		
			List<EmpDTO> list = JdbcTemplate.query(sb.toString(), rm);
		
		return list;
		
	}

	@Override
	public EmpDTO selectOne(int no) {
		sb.setLength(0);
		sb.append("select * from emp ");
		sb.append("where empno = ? ");
		
		RowMapper<EmpDTO> rm = new RowMapper<EmpDTO>() {
			@Override
			public EmpDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return new EmpDTO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getInt(6), rs.getInt(7), rs.getInt(8));
			}
			
		};
		
		//쿼리문에 들어갈 ? 값을 넣기 위해 작성함. -> 사용자가 입력한 번호 = no
		EmpDTO dto = JdbcTemplate.queryForObject(sb.toString(), rm, no);
		return dto;
	}

	@Override
	public void insertOne(EmpDTO dto) {
		sb.setLength(0);
		sb.append("insert into emp ");
		sb.append("values (?, ?, ?, ?, ?, ?, ?, ?) ");
		
		//입력만 하면 됨. 받아오는 작업x
//		jdbcTemplate.update(sql문, ?에 들어갈 값을 (,)를 기준으로 순서대로 입력)
		int result = JdbcTemplate.update(sb.toString(), dto.getEmpno(), dto.getEname(), dto.getJob(), dto.getMgr(), dto.getHiredate(), dto.getSal(), dto.getComm(), dto.getDeptno());
		
		System.out.println("insert 결과:"+result);
		
	}

	@Override
	public void updateOne(EmpDTO dto) {
		sb.setLength(0);
		sb.append("update emp ");
		sb.append("set ename = ?, job =?, mgr=?, hiredate=?, sal=?, comm=?, deptno=? ");
		sb.append("where empno = ? ");
		
		int result = JdbcTemplate.update(sb.toString(),  dto.getEmpno(), dto.getEname(), dto.getJob(), dto.getMgr(), dto.getHiredate(), dto.getSal(), dto.getComm(), dto.getDeptno());
		System.out.println("update 결과:"+result);
		
	}

	@Override
	public void deleteOne(int no) {
		sb.setLength(0);
		sb.append("delete from emp ");
		sb.append("where empno = ? ");
		
		int result = JdbcTemplate.update(sb.toString(), no);
		System.out.println("delete 결과:"+result);
		
	}


}
