package spring_app14_jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;


public class TestMain {
	public static void main(String[] args) {
		
	ApplicationContext context = new GenericXmlApplicationContext("app.xml");
	
	Dao d = context.getBean("dao", Dao.class);
	
	//전체 데이터를 list 인터페이스 객체로 리턴
	List<EmpDTO> list = d.selectAll();
	
	for(EmpDTO dto : list) {
		System.out.println(dto.getEmpno()+"\t"+dto.getEname()+"\t"+dto.getJob()+"\t"+dto.getMgr()+"\t"+dto.getHiredate()+"\t"+dto.getSal()+"\t"+dto.getComm()+"\t"+dto.getDeptno());
	
	}
	
	System.out.println("-------------------------");
	EmpDTO dto1 = d.selectOne(7839);
	System.out.println(dto1.getEmpno()+"\t"+dto1.getEname()+"\t"+dto1.getJob()+"\t"+dto1.getMgr()+"\t"+dto1.getHiredate()+"\t"+dto1.getSal()+"\t"+dto1.getComm()+"\t"+dto1.getDeptno());
	
	
	//emp에 맞춰서 추가하면 됨.
	System.out.println("-------------------------");
//	DeptDTO dto2 = new DeptDTO(60, "영업", "체코");
//	d.insertOne(dto2);
	
	
	System.out.println("-------------------------");
//	DeptDTO dto3 = new DeptDTO(60, "QA", "뉴욕");
//	d.updateOne(dto3);
	
	System.out.println("-------------------------");
//	d.deleteOne(60);
	}
}


