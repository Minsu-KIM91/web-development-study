package kr.co.goott.app.mybatis;


import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;


//SqlSession 객체가 가져가야할 객체
//singleTone
public class ConnectionManager {
	static SqlSessionFactory factory;
	
	//new 되기 전에 먼저 실행되는 코드 블럭(static{}) - 이 클래스가 메모리에 로딩될 때 같이 실행되는 블럭.
	static {
		try {
			Reader r = Resources.getResourceAsReader("resource/ConfigMap.xml");
			
			SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
			factory = builder.build(r);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}//static block end
	
	public static SqlSessionFactory getFactory() {
		return factory;
	}

}
