package kr.co.goott.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class HelloController implements Controller {
	
	
	
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		//ModelAndView : Model + View
		//Model : 전달할 데이터
		//View : 찾아갈 view name
		
		ModelAndView mav = new ModelAndView();
//		mav.addObject("속성이름(변수)", 전달객체);
		mav.addObject("msg", "반갑습니다. 돈 그만쓸까요? 노트북까지만 살까요?");
		mav.setViewName("hello");	
		
		return mav;
	}
	
	
	
	
	
}
