package spring_web03_hw;

public interface Hello {
	public String sayHello();
	
}
