package kr.co.goott.control;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

// 이전까지는 하나의 컨트롤러가 하나의 주소를 가지므로 하나의 일밖에 못하게 되는 단점이 발생
// 다량의 컨트롤러가 만들어져야 한다는 부담감이 생김
// 이 단점 보안을 위해 annotation 사용

@Controller
public class SeleceController {

	@RequestMapping(value = "selectMenu.do")
	public ModelAndView aaa() {
		return new ModelAndView("menu", "test1", "아무거나");
		
	}
	
	@RequestMapping(value = "data.do")
	public ModelAndView bbb() {
		return new ModelAndView("menu", "test2", "이것저것");
	}
}
