package spring_web07_controller_anno_hw;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ViewMenuController {

		@RequestMapping(value = "viewData.do")
		public String show(HttpServletRequest req) {
			String data = req.getParameter("data");
			req.setAttribute("message", data);
			
			return "view";
		}
		
//		public ModelAndView aaa() {
//			return new ModelAndView("show", "test1", "쇼쇼쇼");
//		}
		
}
