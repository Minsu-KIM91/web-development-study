package spring_web08;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@RequestMapping(value = "/hello.do")
	public ModelAndView hello() {
		return new ModelAndView("test", "msg", "HelloControllerMsg");
	}
	
	@RequestMapping("/h.do")
	public String aaa(HttpServletRequest req) {
		
		String data = "HelloController_req";
		
		req.setAttribute("data", data);
		return "index";
	}
	
	@RequestMapping("/h2.do")
	public String bbb(Model model) {
		model.addAttribute("modelData", "HelloController_model");
		return "index";
	}
}
