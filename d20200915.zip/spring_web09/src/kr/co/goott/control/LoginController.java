package kr.co.goott.control;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

	@RequestMapping(value = "/member/login.do", method = RequestMethod.GET)
	public String loginProcess() {
		return "login/login";
	}
	
	@RequestMapping(value = "/member/loginOk.do")
	public String loginOkProcess(
			
			@RequestParam(value = "id")String id,
			Model model
			) {
		
		model.addAttribute("id", id);
		
		return "login/loginOk";
		
	}
}
