package kr.co.goott.control;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.co.goott.dto.MemberDTO;

@Controller
public class RegisterController {
	
	@RequestMapping(value = "/register/step1.do")
	public String processStep1() {
		return "step1";
	}
	
	// 같은 카테고리면 앞에 부분은 동일하게 하는게 좋음(/register << 이 부분)
	@RequestMapping(value = "/register/step2.do")
	public String processStep2(HttpServletRequest req) {
		
		String ck = req.getParameter("ck");
		
		// 체크가 되면 어떤 값이라도 들어오니까 null이면 유지고 체크가 되면 step2로 이동됨
		if(ck == null) {
			return "step1";
		}else {
			return "step2";
		}
	}
	
//	@RequestMapping(value = "/register/step3.do")
//	public String processStep3(
//			
//			@RequestParam(value = "no", defaultValue = "0")int no, // 형변환이 바로 가능
//			@RequestParam(value = "id", defaultValue = "unknown", required = true)String id, // 기본값 지정, 필수값 지정
//			@RequestParam(value = "id")String id,
//			@RequestParam(value = "pwd")String pwd,
//			@RequestParam(value = "confirm")String confirm,
//			@RequestParam(value = "email")String email,
//			Model model
//			) {
//		
//		System.out.println(id + " " + pwd + " " + confirm + " " + email);
//		
//		// 추후에는 DB에 값을 입력하는 형태로 되어야함
//		MemberDTO dto = new MemberDTO();
//		dto.setId(id);
//		dto.setPwd(pwd);
//		dto.setConfirm(confirm);
//		dto.setEmail(email);
//		
//		OracleDAO dao = new OracleDAO();
//		MysqlDAO dao = new MysqlDAO();
//		
//		model.addAttribute("dto", dto);
//		
//		return "welcome";
			
	@RequestMapping("/register/step3.do")
	public String processStep3(@ModelAttribute()MemberDTO dto, Model model) {
		
		model.addAttribute("dto", dto);
		
		return "welcome";
	}
	
//	@RequestMapping("/main")
//	public String processStep4() {
//		return "main";
//	}
}








