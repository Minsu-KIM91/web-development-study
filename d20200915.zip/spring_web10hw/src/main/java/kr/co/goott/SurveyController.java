package kr.co.goott;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SurveyController {

	@RequestMapping(value = "/survey/survey.goott")
	public String processStep1() {
		return "survey/surveyForm";
	}
	
	@RequestMapping(value = "/survey/surveyOk.goott")
	public String processStep2(HttpServletRequest req) {
		String[] imgName = req.getParameterValues("ck");
		
		if(imgName==null) {
			return "surveyForm";
		}else {
			req.setAttribute("img", imgName);
			return "survey/submitted";
		}
		/*
		 * 에러가 발생하면 console에 log가 떠요
		 * WARN : org.springframework.web.servlet.PageNotFound - No mapping for GET /goott/survey/%3Cc:url%20value='/resources/mak.jpg'%20/%3E
WARN : org.springframework.web.servlet.PageNotFound - No mapping for GET /goott/survey/%3Cc:url%20value='/resource
		 * 
		 */
	}
}
