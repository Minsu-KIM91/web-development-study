package kr.co.goott.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.goott.domain.EmpDTO;
import kr.co.goott.persistence.DAO;

@Controller
public class EmpController {
	
	@Autowired
	DAO dao;

	public void setDao(DAO dao) {
		this.dao = dao;
	}
	
	
	@RequestMapping(value="/emplist")
	public String list(Model model) {
		List<EmpDTO> list = dao.selectAll();
		
		model.addAttribute("list", list);
		
		return "listAll";	
	}
	
	
	
	
	
	
	
	
	
}
