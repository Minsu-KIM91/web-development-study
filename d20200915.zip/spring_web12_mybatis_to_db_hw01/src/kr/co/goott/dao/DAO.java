package kr.co.goott.dao;

import java.util.List;

import kr.co.goott.dto.EmpDTO;

public interface DAO {
	public List<EmpDTO> selectAll();
	public EmpDTO selectOne(int no);
	public void insertOne(EmpDTO empDto);
	public void updateOne(EmpDTO empDto);
	public void deleteOne(int no);
	
}
