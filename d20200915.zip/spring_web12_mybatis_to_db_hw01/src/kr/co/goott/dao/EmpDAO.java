package kr.co.goott.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.co.goott.dto.EmpDTO;

public class EmpDAO implements DAO {

	SqlSession ss;
	
		
	public void setSs(SqlSession ss) {
		this.ss = ss;
	}
	
	

	@Override
	public List<EmpDTO> selectAll() {
		
		return ss.selectList("selectAllEmp");
	}

	@Override
	public EmpDTO selectOne(int no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertOne(EmpDTO empDto) {
		ss.insert("insertOneEmp", empDto);
		
	}

	@Override
	public void updateOne(EmpDTO empDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteOne(int no) {
		// TODO Auto-generated method stub
		
	}

}
